# windows/__init__.py
# This file can be empty